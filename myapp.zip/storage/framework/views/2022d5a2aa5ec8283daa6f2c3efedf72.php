

<button <?php echo e($attributes->merge(['type'=>'submit', 'class'=>'btn btn-primary btn-lg btn-block mb-3'])); ?>>
    <?php echo e($slot); ?>

</button><?php /**PATH C:\laragon\www\laraGisleaf\resources\views/components/primary-button.blade.php ENDPATH**/ ?>