<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <form id="RegisterValidation" novalidate="novalidate" method="POST" action="<?php echo e(route('edit-data', $tempats->id)); ?>"
        enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field("PUT"); ?>
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Tambah Tempat</h4>
            </div>
            <div class="card-body">
                <div class="form-group has-label">
                    <label>
                        Nama *
                    </label>
                    <input class="form-control" name="nama_tempat" type="text" value="<?php echo e(old('nama_tempat')); ?>" required aria-invalid="true">
                </div>
                <div class="form-group has-label">
                    <div class="row">
                        <div class="col-md-6">
                            <label for="latitude">Latitude *</label>
                            <input type="text" name="latitude" id="latitude" class="form-control" value="<?php echo e(old('latitude')); ?>">
                        </div>
                        <div class="col-md-6">
                            <label for="longitude">Longitude *</label>
                            <input type="text" name="longitude" id="longitude" class="form-control" value="<?php echo e(old('longitude')); ?>">
                        </div>
                    </div>
                </div>
                <div class="form-group has-label">
                    <label>
                        Kategori *
                    </label>
                    <div class="form-group">
                        <div>
                            <select class="selectpicker" data-size="<?php echo e(sizeof($kategori)); ?>" id="Kategori_id"
                                name="Kategori_id" data-style="btn btn-primary" title="PILIH">
                                <option disabled selected>Pilih</option>
                                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama_kategori); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="form-group has-label">
                    <label>
                        deskripsi
                    </label>
                    <input class="form-control" name="deskripsi" type="text" value="<?php echo e(old('deskripsi')); ?>" required aria-invalid="true">
                </div>
                <div class="category form-category">Foto</div>
                <div class="form-group has-label text-center">
                    <div class="fileinput fileinput-new text-center" data-provides="fileinput">
                        <div class="fileinput-new thumbnail">
                            <img src="<?php echo e(asset('assets/img/image_placeholder.jpg')); ?>" alt="splace upload">
                        </div>
                        <div class="fileinput-preview"></div>
                        <div>
                            <span class="btn btn-rose btn-round btn-file">
                                <span class="fileinput-new">Select image</span>
                                <input type="file" name="foto">
                            </span>
                        </div>
                    </div>
                </div>

            </div>
            <div class="card-footer text-center">
                <button type="submit" class="btn btn-primary">Tambah Tempat</button>
            </div>
        </div>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\laraGisleaf\resources\views/edit-data.blade.php ENDPATH**/ ?>